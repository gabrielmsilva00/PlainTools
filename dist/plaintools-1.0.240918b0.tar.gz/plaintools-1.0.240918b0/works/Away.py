from ..src.PlainTools import PlainTools as pt
import PlainToolsB as ptb

print(
    pt.pround(0.1 ** 32, tol=32)
    )