import PlainTools as pt

x = pt.psequence(1e-15)

for i in x:
    print(i)
